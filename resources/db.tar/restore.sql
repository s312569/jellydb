--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.submitters DROP CONSTRAINT submitters_pkey;
ALTER TABLE ONLY public.peps DROP CONSTRAINT peps_pkey;
ALTER TABLE ONLY public.mrnas DROP CONSTRAINT mrnas_pkey;
ALTER TABLE ONLY public.ips DROP CONSTRAINT ips_pkey;
ALTER TABLE ONLY public.contigs DROP CONSTRAINT contigs_pkey;
ALTER TABLE ONLY public.cds DROP CONSTRAINT cds_pkey;
ALTER TABLE ONLY public.blasts DROP CONSTRAINT blasts_pkey;
ALTER TABLE ONLY public.assemblies DROP CONSTRAINT assemblies_pkey;
ALTER TABLE public.submitters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.contigs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.assemblies ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.submitters_id_seq;
DROP TABLE public.submitters;
DROP TABLE public.pmids;
DROP TABLE public.peps;
DROP TABLE public.mrnas;
DROP TABLE public.ips;
DROP SEQUENCE public.contigs_id_seq;
DROP TABLE public.contigs;
DROP TABLE public.cds;
DROP TABLE public.blasts;
DROP SEQUENCE public.assemblies_id_seq;
DROP TABLE public.assemblies;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: assemblies; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE assemblies (
    id integer NOT NULL,
    name character varying NOT NULL,
    abstract text NOT NULL,
    submitter character varying NOT NULL,
    "time" timestamp without time zone DEFAULT now() NOT NULL,
    species character varying NOT NULL
);


ALTER TABLE assemblies OWNER TO jason;

--
-- Name: assemblies_id_seq; Type: SEQUENCE; Schema: public; Owner: jason
--

CREATE SEQUENCE assemblies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE assemblies_id_seq OWNER TO jason;

--
-- Name: assemblies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jason
--

ALTER SEQUENCE assemblies_id_seq OWNED BY assemblies.id;


--
-- Name: blasts; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE blasts (
    acc character varying NOT NULL,
    "time" timestamp without time zone DEFAULT now() NOT NULL,
    hash text NOT NULL
);


ALTER TABLE blasts OWNER TO jason;

--
-- Name: cds; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE cds (
    acc character varying NOT NULL,
    dataset integer NOT NULL,
    description text,
    alphabet character varying NOT NULL,
    sequence text NOT NULL
);


ALTER TABLE cds OWNER TO jason;

--
-- Name: contigs; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE contigs (
    id integer NOT NULL,
    acc character varying NOT NULL,
    dataset integer NOT NULL,
    description text,
    alphabet character varying NOT NULL,
    sequence text NOT NULL
);


ALTER TABLE contigs OWNER TO jason;

--
-- Name: contigs_id_seq; Type: SEQUENCE; Schema: public; Owner: jason
--

CREATE SEQUENCE contigs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE contigs_id_seq OWNER TO jason;

--
-- Name: contigs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jason
--

ALTER SEQUENCE contigs_id_seq OWNED BY contigs.id;


--
-- Name: ips; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE ips (
    acc character varying NOT NULL,
    "time" timestamp without time zone DEFAULT now() NOT NULL,
    hash text NOT NULL
);


ALTER TABLE ips OWNER TO jason;

--
-- Name: mrnas; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE mrnas (
    acc character varying NOT NULL,
    dataset integer NOT NULL,
    description text,
    alphabet character varying NOT NULL,
    sequence text NOT NULL
);


ALTER TABLE mrnas OWNER TO jason;

--
-- Name: peps; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE peps (
    acc character varying NOT NULL,
    dataset integer NOT NULL,
    description text,
    alphabet character varying NOT NULL,
    sequence text NOT NULL
);


ALTER TABLE peps OWNER TO jason;

--
-- Name: pmids; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE pmids (
    did integer NOT NULL,
    pmid integer NOT NULL
);


ALTER TABLE pmids OWNER TO jason;

--
-- Name: submitters; Type: TABLE; Schema: public; Owner: jason; Tablespace: 
--

CREATE TABLE submitters (
    id integer NOT NULL,
    first character varying NOT NULL,
    last character varying NOT NULL,
    email character varying,
    address character varying
);


ALTER TABLE submitters OWNER TO jason;

--
-- Name: submitters_id_seq; Type: SEQUENCE; Schema: public; Owner: jason
--

CREATE SEQUENCE submitters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE submitters_id_seq OWNER TO jason;

--
-- Name: submitters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jason
--

ALTER SEQUENCE submitters_id_seq OWNED BY submitters.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jason
--

ALTER TABLE ONLY assemblies ALTER COLUMN id SET DEFAULT nextval('assemblies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jason
--

ALTER TABLE ONLY contigs ALTER COLUMN id SET DEFAULT nextval('contigs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: jason
--

ALTER TABLE ONLY submitters ALTER COLUMN id SET DEFAULT nextval('submitters_id_seq'::regclass);


--
-- Data for Name: assemblies; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY assemblies (id, name, abstract, submitter, "time", species) FROM stdin;
\.
COPY assemblies (id, name, abstract, submitter, "time", species) FROM '$$PATH$$/2095.dat';

--
-- Name: assemblies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jason
--

SELECT pg_catalog.setval('assemblies_id_seq', 1, true);


--
-- Data for Name: blasts; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY blasts (acc, "time", hash) FROM stdin;
\.
COPY blasts (acc, "time", hash) FROM '$$PATH$$/2102.dat';

--
-- Data for Name: cds; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY cds (acc, dataset, description, alphabet, sequence) FROM stdin;
\.
COPY cds (acc, dataset, description, alphabet, sequence) FROM '$$PATH$$/2098.dat';

--
-- Data for Name: contigs; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY contigs (id, acc, dataset, description, alphabet, sequence) FROM stdin;
\.
COPY contigs (id, acc, dataset, description, alphabet, sequence) FROM '$$PATH$$/2101.dat';

--
-- Name: contigs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jason
--

SELECT pg_catalog.setval('contigs_id_seq', 374, true);


--
-- Data for Name: ips; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY ips (acc, "time", hash) FROM stdin;
\.
COPY ips (acc, "time", hash) FROM '$$PATH$$/2103.dat';

--
-- Data for Name: mrnas; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY mrnas (acc, dataset, description, alphabet, sequence) FROM stdin;
\.
COPY mrnas (acc, dataset, description, alphabet, sequence) FROM '$$PATH$$/2097.dat';

--
-- Data for Name: peps; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY peps (acc, dataset, description, alphabet, sequence) FROM stdin;
\.
COPY peps (acc, dataset, description, alphabet, sequence) FROM '$$PATH$$/2099.dat';

--
-- Data for Name: pmids; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY pmids (did, pmid) FROM stdin;
\.
COPY pmids (did, pmid) FROM '$$PATH$$/2096.dat';

--
-- Data for Name: submitters; Type: TABLE DATA; Schema: public; Owner: jason
--

COPY submitters (id, first, last, email, address) FROM stdin;
\.
COPY submitters (id, first, last, email, address) FROM '$$PATH$$/2093.dat';

--
-- Name: submitters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jason
--

SELECT pg_catalog.setval('submitters_id_seq', 1, true);


--
-- Name: assemblies_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY assemblies
    ADD CONSTRAINT assemblies_pkey PRIMARY KEY (id);


--
-- Name: blasts_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY blasts
    ADD CONSTRAINT blasts_pkey PRIMARY KEY (acc);


--
-- Name: cds_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY cds
    ADD CONSTRAINT cds_pkey PRIMARY KEY (acc);


--
-- Name: contigs_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY contigs
    ADD CONSTRAINT contigs_pkey PRIMARY KEY (id);


--
-- Name: ips_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY ips
    ADD CONSTRAINT ips_pkey PRIMARY KEY (acc);


--
-- Name: mrnas_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY mrnas
    ADD CONSTRAINT mrnas_pkey PRIMARY KEY (acc);


--
-- Name: peps_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY peps
    ADD CONSTRAINT peps_pkey PRIMARY KEY (acc);


--
-- Name: submitters_pkey; Type: CONSTRAINT; Schema: public; Owner: jason; Tablespace: 
--

ALTER TABLE ONLY submitters
    ADD CONSTRAINT submitters_pkey PRIMARY KEY (id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

